"use strict";

$("#table-1").dataTable({
  "columnDefs": [
    { "sortable": true, "targets": [] }
  ]
});
